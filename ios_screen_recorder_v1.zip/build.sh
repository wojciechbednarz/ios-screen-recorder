#!/bin/bash
# Install frontend deps and build
cd frontend
npm install
npm run build
cd ..
