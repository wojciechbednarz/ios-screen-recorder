from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.api.routes import router
from src.utils.logger import logger
from src.database import init_db, check_db_connection
import os

app = FastAPI(
    title="Appium iOS Screen Recorder API",
    description="API for controlling iOS screen recording via Appium",
    version="1.0.0"
)

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, set to specific frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

@app.on_event("startup")
async def startup_event():
    logger.info("Starting up API Server...")
    
    # Initialize database
    try:
        if check_db_connection():
            init_db()
            logger.info("Database initialized successfully")
        else:
            logger.warning("Database connection failed - running without database")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
        logger.warning("Continuing without database...")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down API Server...")
    from src.core.driver import MobileDriver
    MobileDriver.quit_driver()
